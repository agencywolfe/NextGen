<?php
/**
 * Template Name: Full-Width Page
 */

get_template_part( 'page' );

