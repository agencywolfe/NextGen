<?php
/**
 * Template Name: Blog
 */

get_template_part( 'tmpl/blog-custom' );

