<?php
/**
 * Template Name: 404 page
 */

get_template_part( '404' );

