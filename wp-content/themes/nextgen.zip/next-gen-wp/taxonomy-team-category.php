<?php
/**
 * The Team Template
 */

get_template_part( 'archive-team' );

