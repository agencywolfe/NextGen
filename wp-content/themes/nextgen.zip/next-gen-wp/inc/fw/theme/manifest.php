<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['id'] = 'aqualine';

$manifest['supported_extensions'] = array(
	'backups' => array(),
	'megamenu' => array(),
);
