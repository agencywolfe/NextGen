<?php
$GLOBALS['wpmdb_meta']['wp-migrate-db-pro-cli']['version'] = '1.3.5';
