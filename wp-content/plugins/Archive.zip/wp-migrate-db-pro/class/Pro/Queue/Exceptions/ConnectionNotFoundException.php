<?php

namespace DeliciousBrains\WPMDB\Pro\Queue\Exceptions;

use Exception;

class ConnectionNotFoundException extends Exception {
	//
}
